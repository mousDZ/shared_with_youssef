# generic chart :

- customise default quotas for namespaces
- create service account for namespaces and rbac associated with namespace
